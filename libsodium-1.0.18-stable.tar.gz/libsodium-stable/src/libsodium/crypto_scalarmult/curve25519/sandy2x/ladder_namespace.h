#ifndef ladder_namespace_H
#define ladder_namespace_H

#define  ladder  crypto_scalarmult_curve25519_sandy2x_ladder
#define _ladder _crypto_scalarmult_curve25519_sandy2x_ladder

#endif /* ifndef ladder_namespace_H */

